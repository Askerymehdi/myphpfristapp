# chatroom
This is a chatroom website made with PHP and lots of love....

Dependency:
1.	You need to Install XAMPP or WAMPP or MAMPP server. (Recommended XAMPP server)
2.	You need to learn PHP

Run Process:
1.	Download total things.
2.	Open your XAMPP and run Apache and MySQL server.
 
3.	Past them at htdocs folder on XAMPP (Default Path-> C:\xampp\htdocs)
 
4.	Open your phpmyadmin page on browser. (http://localhost/phpmyadmin/)
 
5.	Upload the database(chatroom.sql) on MYSQL database
6.	Then type localhost/chatroom (need to past the total thing on htdocs) 
7.	Then claim a chatroom.
 
8.	Sent this URL to another and chat.
